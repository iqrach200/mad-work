import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Switch, StyleSheet } from 'react-native';

export default function App() {
  const [darkTheme, setDarkTheme] = useState(false);
  const [result, setResult] = useState('');

  const colors = {
    dark: '#22252D',
    buttonDark: '#333333',    // Updated button color to match dark grey
    buttonLight: '#E0E0E0',
    operator: '#505357',
    function: '#414345',
    number: '#FFFFFF',        // Set number text color to white
  };

  const getColor = (light, dark) => (darkTheme ? dark : light);

  const handlePress = (value) => {
    if (value === 'C') {
      setResult('');
    } else if (value === '=') {
      if (/^[\d÷×+\-%.]+$/.test(result)) {
        const processedResult = result.replace('÷', '/').replace('×', '*');
        setResult(eval(processedResult).toString());
      } else {
        setResult('Invalid');
      }
    } else {
      setResult(result + value);
    }
  };

  const Button = ({ title, type }) => {
    let backgroundColor;
    if (type === 'operator') {
      backgroundColor = colors.operator;
    } else if (type === 'function') {
      backgroundColor = colors.function;
    } else {
      backgroundColor = colors.buttonDark; // Use the dark grey button color
    }

    return (
      <TouchableOpacity
        style={[styles.button, { backgroundColor }]}
        onPress={() => handlePress(title)}
      >
        <Text style={[styles.buttonText, { color: colors.number }]}>
          {title}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: getColor(colors.dark, colors.number) }]}>
      <Switch
        value={darkTheme}
        onValueChange={() => setDarkTheme(!darkTheme)}
        thumbColor={getColor(colors.dark, colors.number)}
        trackColor={{ true: colors.buttonLight, false: colors.buttonDark }}
        style={styles.switch}
      />

      <Text style={[styles.resultText, { color: colors.number }]}>
        {result || '0'}
      </Text>

      <View style={styles.buttonContainer}>
        <Button title="C" type="function" />
        <Button title="+/-" type="function" />
        <Button title="%" type="operator" />
        <Button title="÷" type="operator" />

        <Button title="7" type="number" />
        <Button title="8" type="number" />
        <Button title="9" type="number" />
        <Button title="×" type="operator" />

        <Button title="4" type="number" />
        <Button title="5" type="number" />
        <Button title="6" type="number" />
        <Button title="-" type="operator" />

        <Button title="1" type="number" />
        <Button title="2" type="number" />
        <Button title="3" type="number" />
        <Button title="+" type="operator" />

        <Button title="0" type="number" style={{ width: 150 }} />
        <Button title="." type="function" />
        <Button title="=" type="operator" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 20,
  },
  switch: {
    alignSelf: 'flex-end',
    marginRight: 20,
    marginBottom: 10,
  },
  resultText: {
    fontSize: 48,
    width: '90%',
    textAlign: 'right',
    paddingRight: 20,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: '90%',
  },
  button: {
    borderRadius: 35,
    height: 70,
    width: 70,
    margin: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    fontSize: 24,
  },
});
